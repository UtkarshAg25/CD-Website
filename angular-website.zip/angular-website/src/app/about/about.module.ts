import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AboutRoutingModule } from './about-routing.module';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { FoundersComponent } from './components/founders/founders.component';
import { ExperienceComponent } from './components/experience/experience.component';
import { TeamComponent } from './components/team/team.component';
import { ContactComponent } from './components/contact/contact.component';


@NgModule({
  declarations: [
    LoginComponent,
    RegistrationComponent,
    FoundersComponent,
    ExperienceComponent,
    TeamComponent,
    ContactComponent
  ],
  imports: [
    CommonModule,
    AboutRoutingModule
  ],
  exports:[
    LoginComponent,
    RegistrationComponent,
    FoundersComponent,
    ExperienceComponent,
    TeamComponent,
    ContactComponent
  ]

})
export class AboutModule { }
