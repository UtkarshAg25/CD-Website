import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { FoundersComponent } from './components/founders/founders.component';
import { ExperienceComponent } from './components/experience/experience.component';
import { TeamComponent} from './components/team/team.component';
import { ContactComponent } from './components/contact/contact.component';



const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },

  {
    path: 'registration',
    component: RegistrationComponent
  },

  {
    path: 'founders',
    component: FoundersComponent
  },

  {
    path: 'experience',
    component: ExperienceComponent
  },


  {
    path: 'team',
    component: TeamComponent
  },

  {
    path: 'contact',
    component: ContactComponent
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AboutRoutingModule { }
