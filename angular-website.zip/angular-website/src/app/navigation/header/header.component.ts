import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  constructor(private router: Router){}
  architect(){
    this.router.navigate(['services/architecture'])
  }
  Interior(){
    this.router.navigate(['services/interior'])
  }
  Furniture(){
    this.router.navigate(['services/furniture'])
  }
  Furnishings(){
    this.router.navigate(['services/furnishings'])
  }
  Login(){
    this.router.navigate(['about/login'])
  }
   Registration(){
    this.router.navigate(['about/registration'])
   }
   Founders(){
    this.router.navigate(['about/founders'])
   }
  Experience(){
    this.router.navigate(['about/experience'])
  }
    Team(){
    this.router.navigate(['about/team'])
  }
  contact(){
    this.router.navigate(['about/contact'])
  }
}
