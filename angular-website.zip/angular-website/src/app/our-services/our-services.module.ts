import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OurServicesRoutingModule } from './our-services-routing.module';
import { ArchitectureComponent } from './component/architecture/architecture.component';
import { InteriorComponent } from './component/interior/interior.component';
import { FurnitureComponent } from './component/furniture/furniture.component';
import { FurnishingComponent } from './component/furnishing/furnishing.component';


@NgModule({
  declarations: [
    ArchitectureComponent,
    InteriorComponent,
    FurnitureComponent,
    FurnishingComponent
  ],
  imports: [
    CommonModule,
    OurServicesRoutingModule
  ],
  exports:[
    ArchitectureComponent,
    InteriorComponent,
    FurnitureComponent,
    FurnishingComponent
  ]
})
export class OurServicesModule { }
