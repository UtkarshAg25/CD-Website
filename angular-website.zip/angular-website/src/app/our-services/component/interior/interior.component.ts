import { Component } from '@angular/core';

@Component({
  selector: 'app-interior',
  templateUrl: './interior.component.html',
  styleUrl: './interior.component.css'
})
export class InteriorComponent {

}
