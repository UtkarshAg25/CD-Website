import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ArchitectureComponent } from './component/architecture/architecture.component';
import { InteriorComponent } from './component/interior/interior.component';
import { FurnishingComponent } from './component/furnishing/furnishing.component';
import { FurnitureComponent } from './component/furniture/furniture.component';

const routes: Routes = [
  {
    path: 'architecture',
    component: ArchitectureComponent
  },
  {
    path: 'interior',
    component: InteriorComponent
  },
  {
    path: 'furniture',
    component: FurnitureComponent
  },
  {
    path: 'furnishings',
    component: FurnishingComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OurServicesRoutingModule { }
