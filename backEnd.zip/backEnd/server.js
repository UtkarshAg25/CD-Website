let express = require('express');
let cors = require('cors');
let bodyParser = require('body-parser')
let mongoose = require('mongoose')
let config = require('./config/config')


let app = express();



let UserRoute = require('./routes/userRoute');


//Middlewares
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.use(cors());

app.use('/api/', UserRoute);

app.listen(config.port, (err)=>{
    if(err){
        console.log('Error in starting the server');
    } else{
        console.log('Server started at port ' +config.port);
    }
});

mongoose.connect(config.database);
mongoose.connection.on('Connected', (err)=> {
    if(err){
        console.log('Error in connection database')
    }else{
        console.log('Connected to Db at port 27017')
    }
})
